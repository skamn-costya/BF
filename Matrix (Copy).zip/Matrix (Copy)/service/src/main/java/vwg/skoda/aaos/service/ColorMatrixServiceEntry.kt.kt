package vwg.skoda.aaos.service

import android.os.IInterface
import android.os.IBinder
import android.util.Log

object ColorMatrixServiceEntry {
    private const val TAG = "ColorMatrixServiceEntry"

    /**
     * Регистрирует системный сервис через ServiceManager.
     * Используем рефлексию, чтобы проект собирался в Android Studio.
     *
     * @param service объект, реализующий IInterface (наш ColorMatrixService)
     */
    @JvmStatic
    fun startService(service: IInterface) {
        try {
            // Получаем класс ServiceManager через рефлексию
            val clazz = Class.forName("android.os.ServiceManager")
            val addServiceMethod = clazz.getMethod("addService", String::class.java, IBinder::class.java)

            // Вызываем addService("colormatrix", service.asBinder())
            val binder = service.asBinder()
            addServiceMethod.invoke(null, "colormatrix", binder)

            Log.i(TAG, "ColorMatrixService registered via reflection")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register ColorMatrixService", e)
        }
    }
}
