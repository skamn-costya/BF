package vwg.skoda.aaos.service

import android.os.IColorMatrixService
import android.util.Log
import android.view.SurfaceControl

class ColorMatrixService : IColorMatrixService.Stub() {

    private val TAG = "ColorMatrixService"
    private val mMatrix = FloatArray(9) { i -> if (i % 4 == 0) 1f else 0f } // identity

    // Метод setColorMatrix — точно совпадает с AIDL
    override fun setColorMatrix(matrix: FloatArray) {
        if (matrix.size != 9) {
            throw IllegalArgumentException("Matrix must have 9 floats")
        }

        synchronized(mMatrix) {
            System.arraycopy(matrix, 0, mMatrix, 0, 9)
        }

        val t = SurfaceControl.Transaction()
        t.setColorTransform(null, matrix, null)
        t.apply()

        Log.i(TAG, "Color matrix updated")
    }

    // Метод getColorMatrix — без nullable
    override fun getColorMatrix(): FloatArray {
        return synchronized(mMatrix) { mMatrix.clone() }
    }
}
