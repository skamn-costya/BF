plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
}

android {
    namespace = "vwg.skoda.aaos.service"
    compileSdk = 35

    defaultConfig {
        applicationId = "vwg.skoda.aaos.service"
        minSdk = 33
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        // Для system app потребуется platform key при установке в /system/priv-app
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isMinifyEnabled = false
        }
    }

    // Важно: AIDL source directory
    sourceSets {
        getByName("main") {
            java.srcDirs("src/main/java")
            aidl.srcDirs("src/main/aidl")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
}