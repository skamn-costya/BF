package vwg.skoda.aaos.matrix

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue


object SettingsHolder {
    var settints by mutableStateOf(Settings())

    fun init() {
//        val sysprop = Settings()
//        var value: String
//
//        for (idx in 0..3) {
//            value = sysprop.getSysProp("persist.ns_blf_settings.preset_0${idx}_ns")
//            if (value.isNotEmpty())
//                setPresetMatrixNS(idx, value)
//        }
//        value = sysprop.getSysProp("persist.ns_blf_settings.enable_ns")
//        if (value.isNotEmpty())
//            setEnableNS(value.toBoolean())
//        value = sysprop.getSysProp("persist.ns_blf_settings.mode_ns")
//        if (value.isNotEmpty())
//            setModeNS(value.toInt())
//        value = sysprop.getSysProp("persist.ns_blf_settings.preset_ns")
//        if (value.isNotEmpty())
//            setPresetNS(value.toInt())
//
//        for (idx in 0..6) {
//            value = sysprop.getSysProp("persist.ns_blf_settings.preset_0${idx}_blf")
//            if (value.isNotEmpty())
//                setPresetMatrixBLF(idx, value)
//        }
//        value = sysprop.getSysProp("persist.ns_blf_settings.enable_blf")
//        if (value.isNotEmpty())
//            setEnableBLF(value.toBoolean())
//        value = sysprop.getSysProp("persist.ns_blf_settings.mode_blf")
//        if (value.isNotEmpty())
//            setModeBLF(value.toInt())
//        value = sysprop.getSysProp("persist.ns_blf_settings.preset_blf")
//        if (value.isNotEmpty())
//            setPresetBLF(value.toInt())
//
//        value = sysprop.getSysProp("persist.ns_blf_settings.enable_sm")
//        if (value.isNotEmpty())
//            setEnableSM(value.toBoolean())
    }

    fun writePropMatrix(value: Int) {
//        val sysprop = SysProp()
        var matrixStr = "1,0,0,0,1,0,0,0,1"
        if (settints.enable_blf) {
            when (value) {
                0 -> matrixStr = settints.preset_00_blf
                1 -> matrixStr = settints.preset_01_blf
                2 -> matrixStr = settints.preset_02_blf
                3 -> matrixStr = settints.preset_03_blf
                4 -> matrixStr = settints.preset_04_blf
                5 -> matrixStr = settints.preset_05_blf
                6 -> matrixStr = settints.preset_06_blf
                else -> { // Note the block
                    println("ns_blf_settings: call writePropMatrix with wrong preset index")
                }
            }
        } else if (settints.enable_ns) {
            when (value) {
                0 -> matrixStr = settints.preset_00_ns
                1 -> matrixStr = settints.preset_01_ns
                2 -> matrixStr = settints.preset_02_ns
                3 -> matrixStr = settints.preset_03_ns
                else -> { // Note the block
                    println("ns_blf_settings: call writePropMatrix with wrong preset index")
                }
            }
        }
//        if (sysprop.setSysProp("persist.system.skoda_blf_matrix", matrixStr))
//            println("ns_blf_settings: persist.system.skoda_blf_matrix is set (${matrixStr})")
//        else
//            println("ns_blf_settings: persist.system.skoda_blf_matrix is FAILED (${matrixStr})")
    }

    fun Disabel_BLF_NS() {
        settints = settints.copy(enable_ns = false, enable_blf = false)
//        val sysprop = SysProp()
//        if (sysprop.setSysProp("persist.ns_blf_settings.enable_ns", false.toString()))
//            println("ns_blf_settings: persist.ns_blf_settings.enable_ns is set")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.enable_ns is FAILED")
//        if (sysprop.setSysProp("persist.ns_blf_settings.enable_blf", false.toString()))
//            println("ns_blf_settings: persist.ns_blf_settings.enable_blf is set")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.enable_blf is FAILED")
    }

///////////////////////////////////////////////// Night Shift /////////////////////////////////////////////////
    fun setPresetMatrixNS(idx: Int, value: String) {
//        val sysprop = SysProp()
        when (idx) {
            0 -> settints = settints.copy(preset_00_ns = value)
            1 -> settints = settints.copy(preset_01_ns = value)
            2 -> settints = settints.copy(preset_02_ns = value)
            3 -> settints = settints.copy(preset_03_ns = value)
        }
//        if (sysprop.setSysProp("persist.ns_blf_settings.preset_0${idx}_ns", value))
//            println("ns_blf_settings: persist.ns_blf_settings.preset_0${idx}_ns is set")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.preset_0${idx}_ns is FAILED")
    }

    fun setEnableNS(value: Boolean) {
        settints = settints.copy(enable_ns = value)
        if (value)
            setEnableBLF(false)
//        val sysprop = SysProp()
//        if (sysprop.setSysProp("persist.ns_blf_settings.enable_ns", value.toString()))
//            println("ns_blf_settings: persist.ns_blf_settings.enable_ns is set")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.enable_ns is FAILED")
        writePropMatrix(settints.preset_ns)
    }

    fun getEnableNS(): Boolean {
        return settints.enable_ns
    }

    fun setModeNS(value: Int) {
        settints = settints.copy(mode_ns = value)
//        val sysprop = SysProp()
//        if (sysprop.setSysProp("persist.ns_blf_settings.mode_ns", value.toString()))
//            println("ns_blf_settings: set persist.ns_blf_settings.mode_ns is ok")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.mode_ns is FAILED")
    }

    fun getModeNS(): Int {
        return settints.mode_ns
    }

    fun setFromNS(value: String) {
        settints = settints.copy(from_ns = value)
    }

    fun getFromNS(): String {
        return settints.from_ns
    }

    fun setTillNS(value: String) {
        settints = settints.copy(till_ns = value)
    }

    fun getTillNS(): String {
        return settints.till_ns
    }

    fun setPresetNS(value: Int) {
        settints = settints.copy(preset_ns = value)
        if(settints.enable_ns)
            writePropMatrix(settints.preset_ns)
//        val sysprop = SysProp()
//        if (sysprop.setSysProp("persist.ns_blf_settings.preset_ns", value.toString()))
//            println("ns_blf_settings: set persist.ns_blf_settings.preset_ns is ok")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.preset_ns is FAILED")
    }

    fun getPresetNS(): Int {
        return settints.preset_ns
    }

///////////////////////////////////////////////// Blue Light Filter /////////////////////////////////////////////////

    fun setPresetMatrixBLF(idx: Int, value: String) {
//        val sysprop = SysProp()
        var setresult = false
        when (idx) {
            0 -> { settints = settints.copy(preset_00_blf = value)
//                    setresult = sysprop.setSysProp("persist.ns_blf_settings.preset_00_blf", value)
                }
            1 -> { settints = settints.copy(preset_01_blf = value)
//                    setresult = sysprop.setSysProp("persist.ns_blf_settings.preset_01_blf", value)
                }
            2 -> { settints = settints.copy(preset_02_blf = value)
//                    setresult = sysprop.setSysProp("persist.ns_blf_settings.preset_02_blf", value)
                }
            3 -> { settints = settints.copy(preset_03_blf = value)
//                    setresult = sysprop.setSysProp("persist.ns_blf_settings.preset_03_blf", value)
                }
            4 -> { settints = settints.copy(preset_04_blf = value)
//                    setresult = sysprop.setSysProp("persist.ns_blf_settings.preset_04_blf", value)
                }
            5 -> { settints = settints.copy(preset_05_blf = value)
//                    setresult = sysprop.setSysProp("persist.ns_blf_settings.preset_05_blf", value)
                }
            6 -> { settints = settints.copy(preset_06_blf = value)
//                    setresult = sysprop.setSysProp("persist.ns_blf_settings.preset_06_blf", value)
                }
        }
        if (setresult)
            println("ns_blf_settings: persist.ns_blf_settings.preset_0${idx}_blf is set")
        else
            println("ns_blf_settings: set persist.ns_blf_settings.preset_0${idx}_blf is FAILED")
    }

    fun setEnableBLF(value: Boolean) {
        settints = settints.copy(enable_blf = value)
        if (value)
            setEnableNS(false)
//        val sysprop = SysProp()
//        if (sysprop.setSysProp("persist.ns_blf_settings.enable_blf", value.toString()))
//            println("ns_blf_settings: persist.ns_blf_settings.enable_blf is set")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.enable_blf is FAILED")
        writePropMatrix(settints.preset_blf)
    }

    fun getEnableBLF(): Boolean {
        return settints.enable_blf
    }

    fun setModeBLF(value: Int) {
        settints = settints.copy(mode_blf = value)
//        val sysprop = SysProp()
//        if (sysprop.setSysProp("persist.ns_blf_settings.mode_blf", value.toString()))
//            println("ns_blf_settings: set persist.ns_blf_settings.mode_blf is ok")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.mode_blf is FAILED")
    }

    fun getModeBLF(): Int {
        return settints.mode_blf
    }

    fun setFromBLF(value: String) {
        settints = settints.copy(from_blf = value)
    }

    fun getFromBLF(): String {
        return settints.from_blf
    }

    fun setTillBLF(value: String) {
        settints = settints.copy(till_blf = value)
    }

    fun getTillBLF(): String {
        return settints.till_blf
    }

    fun setPresetBLF(value: Int) {
        settints = settints.copy(preset_blf = value)
        if (settints.enable_blf)
            writePropMatrix(settints.preset_blf)
//        val sysprop = SysProp()
//        if (sysprop.setSysProp("persist.ns_blf_settings.preset_blf", value.toString()))
//            println("ns_blf_settings: set persist.ns_blf_settings.preset_blf is ok")
//        else
//            println("ns_blf_settings: set persist.ns_blf_settings.preset_blf is FAILED")
    }

    fun getPresetBLF(): Int {
        return settints.preset_blf
    }
}

///////////////////////////////////////////////// System Matrix /////////////////////////////////////////////////

//fun setEnableSM(value: Boolean) {
//    settints = settints.copy(enable_sm = value)
////    if (value) {
////        setEnableNS(false)
////        setEnableBLF(flase)
////    }
//}
//
//fun getEnableSM(): Boolean {
//    return settints.enable_blf
//}