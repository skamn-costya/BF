package vwg.skoda.matrix.aaos.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerDialog
import androidx.compose.material3.TimePickerDialogDefaults
import androidx.compose.material3.TimePickerDisplayMode
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vwg.skoda.matrix.aaos.SettingsHolder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NightShift() {
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp),
    ){
        Row(
            modifier = Modifier
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically
//                    horizontalAlignment =  Alignment.CenterHorizontally
        ) {
            Text("Night Shift", fontSize = 42.sp, color = Color(0xFF78FAAE))
        }
        HorizontalDivider(thickness = 1.dp)
        Row(
            modifier = Modifier
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f),
//                horizontalAlignment =  Alignment.CenterHorizontally
            ) {
                Text("Enable:", fontSize = 20.sp, color = Color.White)
            }
            Column(
                modifier = Modifier
                    .weight(7f)
            ) {
                Switch(
                    checked = SettingsHolder.getEnableNS(),
                    onCheckedChange = {
                        SettingsHolder.setEnableNS(it)
                    }
                )
            }
        }

        val radioOptions = listOf("Always", "Sunset - Sunrise", "Manual")
        val selectedOption = radioOptions[SettingsHolder.getModeNS()]

        // Selection Mode
        HorizontalDivider(thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f),
//                horizontalAlignment =  Alignment.CenterHorizontally
            ) {
                Text(
                    "Select mode:",
                    fontSize = 20.sp,
                    color = Color.White,
                )
            }
            Column(
                modifier = Modifier
                    .weight(3f)
                    .selectableGroup()
            ) {
                Row () {
                    radioOptions.forEach { text ->
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .selectable(
                                    selected = (text == selectedOption),
                                    onClick =
                                        {
                                            SettingsHolder.setModeNS(radioOptions.indexOf(text))
//                                            selectedOption = radioOptions[SysSetHolder.getMode()]
                                        },
                                    role = Role.RadioButton
                                )
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column() {
                                RadioButton(
                                    selected = (text == selectedOption),
                                    onClick = null
                                )
                            }
                            Column() {
                                Text(
                                    text = text,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier
                                        .padding(start = 16.dp),
                                    color = Color.White,
                                )
                            }
                        }
                    }
                }
            }
        }

        var showTimePicker by remember { mutableStateOf(false) }
        val state = rememberTimePickerState()

        if (SettingsHolder.getModeNS() == 2) {
//            HorizontalDivider(thickness = 1.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(7f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "From:",
                        fontSize = 20.sp,
                        color = Color.White,
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .offset(x = 16.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Button(
                        onClick = { showTimePicker = true }
                    ) {
                        Text(SettingsHolder.getFromNS())
                    }
                    if (showTimePicker) {
                        TimePickerDialog(
                            title = { TimePickerDialogDefaults.Title(displayMode = TimePickerDisplayMode.Picker) },
                            onDismissRequest = { showTimePicker = false },
                            confirmButton = {
                                TextButton(
                                    onClick = {
                                        SettingsHolder.setFromNS("".plus(state.hour).plus(":").plus(state.minute))
                                        showTimePicker = false
                                    }
                                ) {
                                    Text("Ok")
                                }
                            },
                            dismissButton = { TextButton(onClick = { showTimePicker = false }) { Text("Cancel") } },
                            modeToggleButton = {},
                        ) {
                            TimePicker(state = state)
                        }
                    }
                }
                Column(
                    modifier = Modifier
                        .weight(1f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "Till:",
                        fontSize = 20.sp,
                        color = Color.White,
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .offset(x = 16.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Button(
                        onClick = { showTimePicker = true }
                    ) {
                        Text(SettingsHolder.getTillNS())
                    }
                    if (showTimePicker) {
                        TimePickerDialog(
                            title = { TimePickerDialogDefaults.Title(displayMode = TimePickerDisplayMode.Picker) },
                            onDismissRequest = { showTimePicker = false },
                            confirmButton = {
                                TextButton(
                                    onClick = {
                                        SettingsHolder.setTillNS("".plus(state.hour).plus(":").plus(state.minute))
                                        showTimePicker = false
                                    }
                                ) {
                                    Text("Ok")
                                }
                            },
                            dismissButton = { TextButton(onClick = { showTimePicker = false }) { Text("Cancel") } },
                            modeToggleButton = {},
                        ) {
                            TimePicker(state = state)
                        }
                    }
                }
            }
        }

        val presetOptions = listOf("2700 K", "3500 K", "4500 K", "5500 K")
        val selectedPresetOption = SettingsHolder.getPresetNS()

        // Selection level (Matrix)
//        HorizontalDivider(thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f),
//                horizontalAlignment =  Alignment.CenterHorizontally
            ) {
                Text(
                    "Select level:",
                    fontSize = 20.sp,
                    color = Color.White,
                )
            }
            Column(
                modifier = Modifier
                    .weight(3f)
            ) {
                SingleChoiceSegmentedButtonRow {
                    presetOptions.forEachIndexed { index, label ->
                        SegmentedButton(
                            shape = SegmentedButtonDefaults.itemShape(
                                index = index,
                                count = presetOptions.size,
                            ),
                            colors = SegmentedButtonDefaults.colors(
                                inactiveContentColor = Color.LightGray,
                                activeContentColor = Color.Black
                            ),
                            icon = {},
                            onClick = {
                                SettingsHolder.setPresetNS(index)
                            },
                            selected = (index == selectedPresetOption),
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
        HorizontalDivider(thickness = 1.dp)
    }
}
